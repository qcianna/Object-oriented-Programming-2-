import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class PersonService {

    public static List<Person> listByGender(List<Person> list, Plec plec) {
        return list.stream()
                .filter(p -> (p.getPlec().equals(plec)))
                .collect(Collectors.toList());
    }

    public static List<Person> listAdults(List<Person> list) {

        return list.stream()
                .filter(p -> (p.getWiek() >= 18))
                .collect(Collectors.toList());
    }

    public static List<Person> listByName(List<Person> list, String imie) {

        return list.stream()
                .filter(p -> (p.getImie().equals(imie)))
                .collect(Collectors.toList());
    }


    public static List<Person> listBySurname(List<Person> list, String nazwisko) {

        return list.stream()
                .filter(p -> (p.getNazwisko().equals(nazwisko)))
                .collect(Collectors.toList());
    }

    public static int sumAge(List<Person> list) {

        return list.stream()
                .mapToInt(p -> p.getWiek())
                .sum();
    }

    public static Map<String, Integer> getMap(List<Person> list) {

        return list.stream()
                .collect(Collectors.toMap(p -> p.getImie() + " " + p.getNazwisko(), p -> p.getWiek()));
    }

    public static List<Person> multiplyAgeList(List<Person> list) {

        return list;
    }
}
