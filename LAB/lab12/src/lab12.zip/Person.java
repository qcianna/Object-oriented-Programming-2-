public class Person {

    private String imie;
    private String nazwisko;
    private Plec plec;
    private int wiek;

    Person(String imie, String nazwisko, Plec plec, int wiek) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.plec = plec;
        this.wiek = wiek;
    }

    public String toString() {
        return imie + " " + nazwisko + " " + plec + " " + wiek;
    }

    public Plec getPlec() {
        return plec;
    }

    public int getWiek() {
        return wiek;
    }

    public String getImie() {
        return imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }
}

enum Plec {KOBIETA, MEZCZYZNA};
